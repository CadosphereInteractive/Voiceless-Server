import secrets

allWords = []
usedWords = []

# Reads all the words from the big list of words
f = open("words.txt")
allWords = f.read().splitlines()
f.close()
print("All words read from words_alpha.txt")

# Creates a list of 256 values, 1 for each number possible in an IP address
while len(usedWords) < 256:
    currentWord = secrets.choice(allWords)
    if (len(currentWord) >= 4 and len(currentWord) <= 7):
        usedWords.append(currentWord)  
usedWords.sort()
print("Created random list of 256 words")

# Writes the new list to a file to be used in the server
f = open("wordList.txt", "w")
f.write("string[] Words = {\n")
for word in usedWords:
    f.write('   "' + word + '",\n')
f.write("};")
f.close
print("Words saved to C# array")