# Readme for the program

This is the program I used to generate the big list of words used in Voiceless

To run it simply run `python3 main.py` and it will print the output to `wordList.txt`

The word list was taken from Deekayen => https://gist.github.com/deekayen/4148741

Note; your list will be different since it's randomly chosen each time, to see the current production list you can view it here => https://github.com/CadosphereInteractive/Voiceless-Server/blob/master/WordList.cs